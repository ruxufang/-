"""像素特征构建器 PixelFeatureBuilder - 16维可微特征"""
import torch
import torch.nn as nn
import torch.nn.functional as F

class PixelFeatureBuilder(nn.Module):
    """构建16维像素特征: tex(3) + sem(3) + cross(8) + pos(2)"""
    def __init__(self, cross_dim=512, cross_reduce_dim=8, map_size=37):
        super().__init__()
        self.map_size = map_size
        
        # cross_feat降维: 512→128→8
        self.cross_reduce = nn.Sequential(
            nn.Linear(cross_dim, 128),
            nn.GELU(),
            nn.Linear(128, cross_reduce_dim)
        )
        
        # 3×3平均池化（用于局部均值和标准差）
        self.avg_pool = nn.AvgPool2d(kernel_size=3, stride=1, padding=1)
    
    def forward(self, tex_map, sem_map, cross_feat):
        """
        tex_map: (B, H, W) 纹理异常图
        sem_map: (B, H, W) 语义异常图
        cross_feat: (B, N, 512) 跨分支增强特征
        return: pixel_feats (B, N, 16)
        """
        B = tex_map.shape[0]
        H, W = self.map_size, self.map_size
        
        # tex特征: 原始值 + 3×3均值 + 3×3标准差 (3维)
        tex_2d = tex_map.unsqueeze(1)  # (B, 1, H, W)
        tex_val = tex_2d.flatten(2).permute(0, 2, 1)  # (B, N, 1)
        tex_mean = self.avg_pool(tex_2d).flatten(2).permute(0, 2, 1)  # (B, N, 1)
        tex_sq_mean = self.avg_pool(tex_2d ** 2).flatten(2).permute(0, 2, 1)
        tex_std = torch.sqrt(torch.clamp(tex_sq_mean - tex_mean ** 2, min=1e-8))  # (B, N, 1)
        tex_feats = torch.cat([tex_val, tex_mean, tex_std], dim=-1)  # (B, N, 3)
        
        # sem特征: 原始值 + 3×3均值 + 3×3标准差 (3维)
        sem_2d = sem_map.unsqueeze(1)  # (B, 1, H, W)
        sem_val = sem_2d.flatten(2).permute(0, 2, 1)
        sem_mean = self.avg_pool(sem_2d).flatten(2).permute(0, 2, 1)
        sem_sq_mean = self.avg_pool(sem_2d ** 2).flatten(2).permute(0, 2, 1)
        sem_std = torch.sqrt(torch.clamp(sem_sq_mean - sem_mean ** 2, min=1e-8))
        sem_feats = torch.cat([sem_val, sem_mean, sem_std], dim=-1)  # (B, N, 3)
        
        # cross特征: 512→8维 (8维)
        cross_feats = self.cross_reduce(cross_feat)  # (B, N, 8)
        
        # 位置编码: x, y ∈ [-1, 1] (2维)
        rows = torch.linspace(-1, 1, H, device=tex_map.device)
        cols = torch.linspace(-1, 1, W, device=tex_map.device)
        grid_y, grid_x = torch.meshgrid(rows, cols, indexing='ij')
        pos_feats = torch.stack([grid_x.flatten(), grid_y.flatten()], dim=-1)  # (N, 2)
        pos_feats = pos_feats.unsqueeze(0).expand(B, -1, -1)  # (B, N, 2)
        
        # 拼接: 3 + 3 + 8 + 2 = 16维
        pixel_feats = torch.cat([tex_feats, sem_feats, cross_feats, pos_feats], dim=-1)
        
        return pixel_feats  # (B, N, 16)
