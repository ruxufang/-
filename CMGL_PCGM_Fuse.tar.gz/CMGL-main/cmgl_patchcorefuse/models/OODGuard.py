"""OOD守护模块 - 马氏距离检测 + 固定α回退"""
import torch
import torch.nn as nn
import numpy as np

class OODGuard:
    """OOD守护模块：分布外检测，异常时回退到固定α融合"""
    def __init__(self, threshold=3.0, ood_ratio_threshold=0.5, alpha=0.5):
        self.threshold = threshold
        self.ood_ratio_threshold = ood_ratio_threshold
        self.alpha = alpha
        self.mu = None
        self.sigma_inv = None
    
    def fit(self, pixel_feats):
        """用正常样本的像素特征估计均值和协方差逆矩阵
        pixel_feats: (N_total, 16) 所有正常图的所有patch特征
        """
        self.mu = np.mean(pixel_feats, axis=0)
        sigma = np.cov(pixel_feats, rowvar=False)
        self.sigma_inv = np.linalg.inv(sigma + 1e-6 * np.eye(sigma.shape[0]))
    
    def save(self, path):
        np.savez(path, mu=self.mu, sigma_inv=self.sigma_inv,
                 threshold=self.threshold, ood_ratio_threshold=self.ood_ratio_threshold)
    
    def load(self, path):
        data = np.load(path)
        self.mu = data['mu']
        self.sigma_inv = data['sigma_inv']
        self.threshold = float(data['threshold'])
        self.ood_ratio_threshold = float(data['ood_ratio_threshold'])
    
    def predict(self, pixel_feats, mlp_score, tex_map, sem_map):
        """
        pixel_feats: (B, N, 16) numpy array
        mlp_score: (B, N) MLP融合分数
        tex_map: (B, N) 纹理异常图
        sem_map: (B, N) 语义异常图
        return: final_score (B, N), ood_flags (B,)
        """
        B, N, D = pixel_feats.shape
        final_scores = []
        ood_flags = []
        
        for b in range(B):
            # 马氏距离
            diff = pixel_feats[b] - self.mu  # (N, 16)
            mahal_dist = np.sum(diff @ self.sigma_inv * diff, axis=1)  # (N,)
            
            # OOD mask
            ood_mask = mahal_dist > self.threshold
            ood_ratio = np.mean(ood_mask)
            
            if ood_ratio > self.ood_ratio_threshold:
                # OOD: 固定α融合
                final = self.alpha * tex_map[b] + (1 - self.alpha) * sem_map[b]
                ood_flags.append(True)
            else:
                # 分布内: 使用MLP score
                final = mlp_score[b]
                ood_flags.append(False)
            
            final_scores.append(final)
        
        return np.array(final_scores), np.array(ood_flags)
