"""PatchCore纹理分支 - GPU加速KNN"""
import numpy as np
import torch

class PatchCore:
    """PatchCore异常检测：正常样本建库 + GPU KNN检索"""
    def __init__(self, coreset_ratio=0.1, n_neighbors=3, device='cuda:0'):
        self.coreset_ratio = coreset_ratio
        self.n_neighbors = n_neighbors
        self.device = device
        self.memory_bank = None  # torch.Tensor on GPU
        self.normalizer = None
    
    def build_memory_bank(self, features):
        """用正常样本特征构建Memory Bank
        features: numpy array (N, D)
        """
        print(f"  PatchCore: 原始特征数={features.shape[0]}, 维度={features.shape[1]}")
        n_coreset = max(1, int(len(features) * self.coreset_ratio))
        if len(features) > n_coreset:
            indices = np.random.choice(len(features), n_coreset, replace=False)
            self.memory_bank = torch.from_numpy(features[indices]).float().to(self.device)
        else:
            self.memory_bank = torch.from_numpy(features).float().to(self.device)
        print(f"  PatchCore: Coreset后={self.memory_bank.shape[0]} (GPU)")
        
        # 计算正常距离分布（只用1万样本，加速）
        n_sample = min(10000, len(features))
        sample_indices = np.random.choice(len(features), n_sample, replace=False)
        sample_feats = torch.from_numpy(features[sample_indices]).float().to(self.device)
        
        with torch.no_grad():
            distances = self._knn_distance(sample_feats)
        
        max_distances = distances[:, -1].cpu().numpy()
        self.normalizer = {
            'mu': float(np.mean(max_distances)),
            'sigma': float(np.std(max_distances)),
            'p2': float(np.percentile(max_distances, 2)),
            'p98': float(np.percentile(max_distances, 98))
        }
        print(f"  PatchCore: 正常距离 p2={self.normalizer['p2']:.4f}, p98={self.normalizer['p98']:.4f}")
    
    def _knn_distance(self, query):
        """GPU加速KNN距离计算
        query: (N, D) torch.Tensor
        return: (N, k) 距离
        """
        # 分批计算，避免显存溢出
        batch_size = 4096
        all_distances = []
        for i in range(0, len(query), batch_size):
            batch = query[i:i+batch_size]
            # L2距离: ||a-b||^2 = ||a||^2 + ||b||^2 - 2*a*b
            dist = torch.cdist(batch, self.memory_bank, p=2)  # (batch, N_bank)
            topk_dist, _ = torch.topk(dist, self.n_neighbors, dim=1, largest=False)
            all_distances.append(topk_dist)
        return torch.cat(all_distances, dim=0)
    
    def predict(self, features):
        """计算异常分数
        features: numpy array (B, N, D)
        return: anomaly_map (B, N) numpy
        """
        B, N, D = features.shape
        query = torch.from_numpy(features.reshape(-1, D)).float().to(self.device)
        
        with torch.no_grad():
            distances = self._knn_distance(query)
            max_distances = distances[:, -1]
        
        # Global Normalizer
        p2 = self.normalizer['p2']
        p98 = self.normalizer['p98']
        normalized = (max_distances - p2) / (p98 - p2 + 1e-8)
        normalized = torch.clamp(normalized, 0, 1)
        
        return normalized.cpu().numpy().reshape(B, N)
    
    def save(self, path):
        np.savez(path, 
                 memory_bank=self.memory_bank.cpu().numpy(),
                 normalizer=self.normalizer)
    
    def load(self, path):
        data = np.load(path, allow_pickle=True)
        self.memory_bank = torch.from_numpy(data['memory_bank']).float().to(self.device)
        self.normalizer = data['normalizer'].item()
