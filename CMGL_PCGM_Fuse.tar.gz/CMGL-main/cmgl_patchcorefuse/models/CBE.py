"""跨分支注意力增强器 Cross-Branch Enhancer"""
import torch
import torch.nn as nn
import torch.nn.functional as F

class SpatialTransformer(nn.Module):
    """空间自注意力Transformer层"""
    def __init__(self, dim=512, num_heads=8, mlp_ratio=2.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, int(dim * mlp_ratio)),
            nn.GELU(),
            nn.Linear(int(dim * mlp_ratio), dim)
        )
    
    def forward(self, x):
        # x: (B, N, D)
        x_norm = self.norm1(x)
        attn_out, _ = self.attn(x_norm, x_norm, x_norm)
        x = x + attn_out
        x = x + self.mlp(self.norm2(x))
        return x

class CBE(nn.Module):
    """跨分支注意力增强器 Cross-Branch Enhancer"""
    def __init__(self, tex_dim=4096, sem_dim=1024, hidden_dim=256, out_dim=512, num_heads=8, num_layers=2):
        super().__init__()
        # Linear Projection
        self.tex_proj = nn.Sequential(
            nn.Linear(tex_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU()
        )
        self.sem_proj = nn.Sequential(
            nn.Linear(sem_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU()
        )
        
        # 双向交叉注意力
        # 方向1: tex关注sem (tex → sem)
        self.q_tex = nn.Linear(hidden_dim, hidden_dim)
        self.k_sem = nn.Linear(hidden_dim, hidden_dim)
        self.v_sem = nn.Linear(hidden_dim, hidden_dim)
        
        # 方向2: sem关注tex (sem → tex)
        self.q_sem = nn.Linear(hidden_dim, hidden_dim)
        self.k_tex = nn.Linear(hidden_dim, hidden_dim)
        self.v_tex = nn.Linear(hidden_dim, hidden_dim)
        
        self.scale = hidden_dim ** -0.5
        
        # 融合投影
        self.fuse_proj = nn.Linear(hidden_dim * 2, out_dim)
        
        # Spatial Transformer
        self.spatial_transformers = nn.ModuleList([
            SpatialTransformer(out_dim, num_heads) for _ in range(num_layers)
        ])
    
    def forward(self, tex_feats, sem_feats):
        """
        tex_feats: (B, N, 4096) 纹理分支特征
        sem_feats: (B, N, 1024) 语义分支特征
        return: cross_feat (B, N, 512)
        """
        tex = self.tex_proj(tex_feats)  # (B, N, 256)
        sem = self.sem_proj(sem_feats)  # (B, N, 256)
        
        # 方向1: tex关注sem
        q_t = self.q_tex(tex)
        k_s = self.k_sem(sem)
        v_s = self.v_sem(sem)
        attn1 = torch.softmax(q_t @ k_s.transpose(-2, -1) * self.scale, dim=-1)
        tex_out = tex + attn1 @ v_s  # (B, N, 256)
        
        # 方向2: sem关注tex
        q_s = self.q_sem(sem)
        k_t = self.k_tex(tex)
        v_t = self.v_tex(tex)
        attn2 = torch.softmax(q_s @ k_t.transpose(-2, -1) * self.scale, dim=-1)
        sem_out = sem + attn2 @ v_t  # (B, N, 256)
        
        # 融合
        fused = torch.cat([tex_out, sem_out], dim=-1)  # (B, N, 512)
        cross_feat = self.fuse_proj(fused)  # (B, N, 512)
        
        # Spatial Transformer
        for st in self.spatial_transformers:
            cross_feat = st(cross_feat)
        
        return cross_feat
