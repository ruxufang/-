"""类别感知MLP融合模块 Category-Aware MLP Fusion"""
import torch
import torch.nn as nn

class CategoryAwareMLP(nn.Module):
    """类别感知MLP: 16维像素特征 + 768维类别嵌入 → 异常概率"""
    def __init__(self, pixel_dim=16, class_dim=768, hidden_dims=[64, 32], dropout=0.1):
        super().__init__()
        input_dim = pixel_dim + class_dim
        
        layers = []
        prev_dim = input_dim
        for h_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, h_dim),
                nn.ReLU(),
                nn.Dropout(dropout)
            ])
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, 1))
        layers.append(nn.Sigmoid())
        
        self.mlp = nn.Sequential(*layers)
    
    def forward(self, pixel_feats, class_embed):
        """
        pixel_feats: (B, N, 16) 像素特征
        class_embed: (B, 768) 类别文本嵌入
        return: mlp_score (B, N) 每patch异常概率
        """
        B, N, _ = pixel_feats.shape
        # 扩展类别嵌入到每个patch
        class_expanded = class_embed.unsqueeze(1).expand(-1, N, -1)  # (B, N, 768)
        # 拼接
        combined = torch.cat([pixel_feats, class_expanded], dim=-1)  # (B, N, 784)
        # MLP
        score = self.mlp(combined).squeeze(-1)  # (B, N)
        return score
