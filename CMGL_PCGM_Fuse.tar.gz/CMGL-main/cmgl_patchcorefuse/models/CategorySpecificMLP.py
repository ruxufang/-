"""每类别独立MLP - 每个VisA类别一个MLP，新类别用最接近类别/插值"""
import torch
import torch.nn as nn
import numpy as np

class SingleMLP(nn.Module):
    """单个类别的MLP"""
    def __init__(self, pixel_dim=16, hidden_dims=[64, 32], dropout=0.1):
        super().__init__()
        layers = []
        prev_dim = pixel_dim
        for h_dim in hidden_dims:
            layers.extend([nn.Linear(prev_dim, h_dim), nn.ReLU(), nn.Dropout(dropout)])
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, 1))
        layers.append(nn.Sigmoid())
        self.mlp = nn.Sequential(*layers)
    
    def forward(self, pixel_feats):
        return self.mlp(pixel_feats).squeeze(-1)

class CategorySpecificMLP(nn.Module):
    """每类别独立MLP集合"""
    def __init__(self, class_names, pixel_dim=16, hidden_dims=[64, 32], dropout=0.1):
        super().__init__()
        self.class_names = class_names
        self.class_to_idx = {name: i for i, name in enumerate(class_names)}
        self.mlps = nn.ModuleList([
            SingleMLP(pixel_dim, hidden_dims, dropout) for _ in class_names
        ])
    
    def forward(self, pixel_feats, cls_names, class_embeds=None):
        """
        pixel_feats: (B, N, 16)
        cls_names: list of str, batch中每个样本的类别名
        class_embeds: (B, 768) 可选，用于新类别插值
        """
        B, N, _ = pixel_feats.shape
        scores = torch.zeros(B, N, device=pixel_feats.device)
        
        for b in range(B):
            cls = cls_names[b]
            if cls in self.class_to_idx:
                # 已知类别：用对应MLP
                idx = self.class_to_idx[cls]
                scores[b] = self.mlps[idx](pixel_feats[b:b+1]).squeeze(0)
            else:
                # 新类别：用所有MLP输出的加权平均（按class_embed相似度）
                if class_embeds is not None:
                    # 计算与已知类别嵌入的相似度
                    # 这里简化：用所有MLP输出的平均
                    all_scores = []
                    for mlp in self.mlps:
                        all_scores.append(mlp(pixel_feats[b:b+1]).squeeze(0))
                    scores[b] = torch.stack(all_scores).mean(dim=0)
                else:
                    # 无嵌入信息，用所有MLP平均
                    all_scores = []
                    for mlp in self.mlps:
                        all_scores.append(mlp(pixel_feats[b:b+1]).squeeze(0))
                    scores[b] = torch.stack(all_scores).mean(dim=0)
        
        return scores
    
    def get_trainable_params(self, cls_name):
        """获取指定类别的MLP参数"""
        if cls_name in self.class_to_idx:
            idx = self.class_to_idx[cls_name]
            return self.mlps[idx].parameters()
        return []
