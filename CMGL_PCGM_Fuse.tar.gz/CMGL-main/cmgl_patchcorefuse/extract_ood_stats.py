"""提取OOD守护模块的统计参数（用正常样本的pixel_feats）"""
import os, sys, json, argparse
import numpy as np
import torch
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from models.model_CLIP import Load_CLIP, tokenize
from models.prompt_ensemble import Prompt_Ensemble, LCBlock
from models.APV import Context_Prompting
from models.UAFM import UAFM
from cmgl_patchcorefuse.models.CBE import CBE
from cmgl_patchcorefuse.models.PixelFeatureBuilder import PixelFeatureBuilder
from cmgl_patchcorefuse.models.OODGuard import OODGuard
from cmgl_patchcorefuse.models.PatchCore import PatchCore
from utils.dataset import VisaDataset

class LinearLayer(nn.Module):
    def __init__(self, dim_in, dim_out, k, model):
        super().__init__()
        self.fc = nn.ModuleList([nn.Linear(dim_in, dim_out) for i in range(k)])
    def forward(self, tokens):
        return [self.fc[i](tokens[i][:, 1:, :]) for i in range(len(tokens))]

def _load_stages(model, params, exclude_key=None):
    for n, m in model.named_parameters():
        if exclude_key and exclude_key in n:
            m.data = params[n].data

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, default='../dataset/mvisa/data')
    parser.add_argument('--checkpoint_path', type=str, default='../my_exps/train_visa/epoch_1_group_id_2.pth')
    parser.add_argument('--model_path', type=str, default='./checkpoints/best_model.pth')
    parser.add_argument('--patchcore_path', type=str, default='./checkpoints/patchcore_memory.npz')
    parser.add_argument('--pretrained_path', type=str, default='../pretrained_weight/ViT-L-14-336px.pt')
    parser.add_argument('--save_path', type=str, default='./checkpoints')
    parser.add_argument('--config_path', type=str, default='../models/model_configs/ViT-L-14.json')
    parser.add_argument('--model', type=str, default='ViT-L-14-336')
    parser.add_argument('--device_id', type=int, default=0)
    parser.add_argument('--features_list', type=int, nargs='+', default=[6, 12, 18, 24])
    parser.add_argument('--image_size', type=int, default=518)
    parser.add_argument('--batch_size', type=int, default=4)
    return parser.parse_args()

def main():
    args = parse_args()
    device = torch.device(f'cuda:{args.device_id}')
    
    with open(args.config_path, 'r') as f:
        model_configs = json.load(f)
    
    model, _, preprocess_test = Load_CLIP(
        args.image_size, args.pretrained_path, device=device,
        deep_prompt_len=1, total_d_layer_len=11)
    model.to(device)
    
    linearlayer = LinearLayer(model_configs['vision_cfg']['width'], model_configs['embed_dim'],
                              len(args.features_list), args.model).to(device)
    New_Lan_Embed = Context_Prompting(model_configs, cla_len=2).to(device)
    prompt_ceshi = Prompt_Ensemble(2, tokenize)
    UFAMTemplate = UAFM(dim_v=model_configs["vision_cfg"]['width'],
                        dim_t=model_configs["text_cfg"]['width'],
                        dim_out=model_configs["vision_cfg"]['width']).to(device)
    model_tf = LCBlock(refine_type="transformer").to(device)
    
    checkpoint = torch.load(args.checkpoint_path, map_location=device)
    linearlayer.load_state_dict(checkpoint["trainable_linearlayer"], strict=False)
    New_Lan_Embed.load_state_dict(checkpoint["New_Lan_Embed"])
    UFAMTemplate.load_state_dict(checkpoint["UFAMTemplate"], strict=False)
    model_tf.load_state_dict(checkpoint["ParallelThenRefine"], strict=False)
    _load_stages(model, checkpoint, "prompt")
    model.eval(); linearlayer.eval(); New_Lan_Embed.eval()
    UFAMTemplate.eval(); model_tf.eval()
    
    cbe = CBE(tex_dim=4096, sem_dim=1024, hidden_dim=256, out_dim=512).to(device)
    pfb = PixelFeatureBuilder(cross_dim=512, cross_reduce_dim=8, map_size=37).to(device)
    model_ckpt = torch.load(args.model_path, map_location=device)
    cbe.load_state_dict(model_ckpt['cbe'])
    pfb.load_state_dict(model_ckpt['pfb'])
    cbe.eval(); pfb.eval()
    
    patchcore = PatchCore()
    patchcore.load(args.patchcore_path)
    
    target_transform = transforms.Compose([
        transforms.Resize((args.image_size, args.image_size)),
        transforms.CenterCrop(args.image_size),
        transforms.ToTensor()
    ])
    dataset = VisaDataset(root=args.data_path, transform=preprocess_test,
                         target_transform=target_transform, mode='test',
                         train_mode="zero", dataset="visa")
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=4)
    prompt_ceshi.build_state_pool(model, device)
    
    print("收集正常样本的pixel_feats...")
    all_feats = []
    with torch.no_grad():
        for items in tqdm(dataloader):
            if items['anomaly'][0] == 1:
                continue
            img = items['img'].to(device)
            cls_names = items['cls_name']
            
            image_features, patch_tokens = model.encode_image(img, args.features_list)
            class_token = New_Lan_Embed.before_extract_feat(patch_tokens, image_features.clone(), use_global=True)
            text_embeddings, _, _ = prompt_ceshi.forward_ensemble(
                model, model_tf, image_features, patch_tokens, class_token, cls_names, device)
            text_embeddings_perm = text_embeddings.permute(0, 2, 1)
            patch_tokens_linear = linearlayer(patch_tokens)
            
            anomaly_maps = []
            sem_feats_list = []
            for layer in range(len(patch_tokens)):
                dense_feature = patch_tokens[layer][:, 1:, :].clone()
                dense_feature_norm = dense_feature / dense_feature.norm(dim=-1, keepdim=True)
                sem_feats_list.append(dense_feature_norm)
                dense_raw = patch_tokens_linear[layer].clone()
                dense_raw = dense_raw / dense_raw.norm(dim=-1, keepdim=True)
                anomaly_prior = (New_Lan_Embed.prompt_temp.exp() * dense_raw @ text_embeddings_perm)
                anomaly_map_new = UFAMTemplate(text_embeddings, dense_feature_norm, anomaly_prior=anomaly_prior)
                B, L, C = anomaly_map_new.shape
                H = int(np.sqrt(L))
                anomaly_map_new = F.interpolate(anomaly_map_new.permute(0, 2, 1).view(B, 2, H, H),
                                                size=37, mode='bilinear', align_corners=True)
                anomaly_map_new = torch.softmax(anomaly_map_new, dim=1)[:, 1, :, :]
                anomaly_maps.append(anomaly_map_new)
            
            sem_map = torch.stack(anomaly_maps, dim=0).mean(dim=0)
            sem_feats = torch.stack(sem_feats_list, dim=0).mean(dim=0)
            tex_feats = torch.cat([pt[:, 1:, :] for pt in patch_tokens], dim=-1)
            
            tex_map_np = patchcore.predict(tex_feats.cpu().numpy())
            tex_map = torch.from_numpy(tex_map_np).float().to(device)
            tex_map_2d = tex_map.view(-1, 37, 37)
            
            cross_feat = cbe(tex_feats, sem_feats)
            pixel_feats = pfb(tex_map_2d, sem_map, cross_feat)  # (B, N, 16)
            all_feats.append(pixel_feats.cpu().numpy().reshape(-1, 16))
            
            if len(all_feats) * args.batch_size * 1369 > 1000000:
                break
    
    all_feats = np.concatenate(all_feats, axis=0)
    print(f"收集到 {all_feats.shape[0]} 个正常patch特征")
    
    ood_guard = OODGuard()
    ood_guard.fit(all_feats)
    ood_guard.save(os.path.join(args.save_path, 'ood_stats.npz'))
    print(f"OOD统计保存到: {args.save_path}/ood_stats.npz")

if __name__ == '__main__':
    main()
