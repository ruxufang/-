"""CMGL-PatchCorefuse 完整训练脚本（加权BCE + 验证集监控）"""
import os, sys, json, argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Subset
from tqdm import tqdm
from sklearn.metrics import roc_auc_score

sys.path.insert(0, '/root/rxfang/CMGL-main')
sys.path.insert(0, '/root/rxfang/CMGL-main/cmgl_patchcorefuse')

from models.model_CLIP import Load_CLIP, tokenize
from models.prompt_ensemble import Prompt_Ensemble, LCBlock
from models.APV import Context_Prompting
from models.UAFM import UAFM
from cmgl_patchcorefuse.models.CBE import CBE
from cmgl_patchcorefuse.models.PixelFeatureBuilder import PixelFeatureBuilder
from cmgl_patchcorefuse.models.CategoryAwareMLP import CategoryAwareMLP
from utils.dataset import VisaDataset

class LinearLayer(nn.Module):
    def __init__(self, dim_in, dim_out, k, model):
        super().__init__()
        self.fc = nn.ModuleList([nn.Linear(dim_in, dim_out) for i in range(k)])
    def forward(self, tokens):
        return [self.fc[i](tokens[i][:, 1:, :]) for i in range(len(tokens))]

def _load_stages(model, params, exclude_key=None):
    for n, m in model.named_parameters():
        if exclude_key and exclude_key in n:
            m.data = params[n].data

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, default='/root/rxfang/CMGL-main/dataset/mvisa/data')
    parser.add_argument('--tex_map_path', type=str, default='/root/rxfang/CMGL-main/cmgl_patchcorefuse/features/tex_maps.npy')
    parser.add_argument('--checkpoint_path', type=str, default='/root/rxfang/CMGL-main/my_exps/train_visa/epoch_1_group_id_2.pth')
    parser.add_argument('--pretrained_path', type=str, default='/root/rxfang/CMGL-main/pretrained_weight/ViT-L-14-336px.pt')
    parser.add_argument('--save_path', type=str, default='/root/rxfang/CMGL-main/cmgl_patchcorefuse/checkpoints')
    parser.add_argument('--config_path', type=str, default='/root/rxfang/CMGL-main/models/model_configs/ViT-L-14.json')
    parser.add_argument('--model', type=str, default='ViT-L-14-336')
    parser.add_argument('--prompt_len', type=int, default=2)
    parser.add_argument('--deep_prompt_len', type=int, default=1)
    parser.add_argument('--total_d_layer_len', type=int, default=11)
    parser.add_argument('--device_id', type=int, default=0)
    parser.add_argument('--features_list', type=int, nargs='+', default=[6, 12, 18, 24])
    parser.add_argument('--image_size', type=int, default=518)
    parser.add_argument('--batch_size', type=int, default=4)
    parser.add_argument('--epochs', type=int, default=30)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--seed', type=int, default=333)
    parser.add_argument('--use_global', type=bool, default=True)
    parser.add_argument('--pos_weight', type=float, default=10.0, help='异常像素权重')
    parser.add_argument('--val_ratio', type=float, default=0.3, help='验证集比例')
    return parser.parse_args()

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def extract_sem_features(model, linearlayer, New_Lan_Embed, prompt_ceshi,
                         UFAMTemplate, model_tf, img, cls_names, device, args):
    image_features, patch_tokens = model.encode_image(img, args.features_list)
    class_token = New_Lan_Embed.before_extract_feat(patch_tokens, image_features.clone(), use_global=args.use_global)
    text_embeddings, _, _ = prompt_ceshi.forward_ensemble(
        model, model_tf, image_features, patch_tokens, class_token, cls_names, device)
    text_embeddings_perm = text_embeddings.permute(0, 2, 1)
    patch_tokens_linear = linearlayer(patch_tokens)
    
    anomaly_maps = []
    sem_feats_list = []
    for layer in range(len(patch_tokens)):
        dense_feature = patch_tokens[layer][:, 1:, :].clone()
        dense_feature_norm = dense_feature / dense_feature.norm(dim=-1, keepdim=True)
        sem_feats_list.append(dense_feature_norm)
        dense_raw = patch_tokens_linear[layer].clone()
        dense_raw = dense_raw / dense_raw.norm(dim=-1, keepdim=True)
        anomaly_prior = (New_Lan_Embed.prompt_temp.exp() * dense_raw @ text_embeddings_perm)
        anomaly_map_new = UFAMTemplate(text_embeddings, dense_feature_norm, anomaly_prior=anomaly_prior)
        B, L, C = anomaly_map_new.shape
        H = int(np.sqrt(L))
        anomaly_map_new = F.interpolate(anomaly_map_new.permute(0, 2, 1).view(B, 2, H, H),
                                        size=37, mode='bilinear', align_corners=True)
        anomaly_map_new = torch.softmax(anomaly_map_new, dim=1)[:, 1, :, :]
        anomaly_maps.append(anomaly_map_new)
    
    sem_map = torch.stack(anomaly_maps, dim=0).mean(dim=0)
    sem_feats = torch.stack(sem_feats_list, dim=0).mean(dim=0)
    tex_feats = torch.cat([pt[:, 1:, :] for pt in patch_tokens], dim=-1)
    return tex_feats, sem_feats, sem_map, text_embeddings

def evaluate(model, linearlayer, New_Lan_Embed, prompt_ceshi, UFAMTemplate, model_tf,
             cbe, pfb, camlp, dataloader, img_path_to_tex, device, args):
    """验证集评估，返回image AUROC"""
    cbe.eval(); pfb.eval(); camlp.eval()
    all_scores = []
    all_labels = []
    
    with torch.no_grad():
        for items in dataloader:
            img = items['img'].to(device)
            cls_names = items['cls_name']
            gt_sp = items['anomaly']
            img_paths = items['img_path']
            
            tex_map_batch = []
            for p in img_paths:
                rel_path = p.replace(args.data_path + '/', '')
                tex_map_batch.append(img_path_to_tex[rel_path])
            tex_map_batch = np.array(tex_map_batch)
            tex_map_2d = torch.from_numpy(tex_map_batch).float().to(device).view(-1, 37, 37)
            
            tex_feats, sem_feats, sem_map, text_embeddings = extract_sem_features(
                model, linearlayer, New_Lan_Embed, prompt_ceshi,
                UFAMTemplate, model_tf, img, cls_names, device, args)
            
            cross_feat = cbe(tex_feats, sem_feats)
            pixel_feats = pfb(tex_map_2d, sem_map, cross_feat)
            class_embed = text_embeddings[:, 0, :]
            mlp_score = camlp(pixel_feats, class_embed)  # (B, N)
            
            # image score = top-2000像素平均（原项目方式）
            k = 100  # 37x37=1369个patch，取top-100约7%
            img_scores = torch.topk(mlp_score, k, dim=1)[0].mean(dim=1)
            
            all_scores.append(img_scores.cpu().numpy())
            all_labels.append(np.array(gt_sp))
    
    all_scores = np.concatenate(all_scores)
    all_labels = np.concatenate(all_labels)
    
    # 归一化
    all_scores = (all_scores - all_scores.min()) / (all_scores.max() - all_scores.min() + 1e-8)
    
    if np.sum(all_labels) > 0 and np.sum(all_labels==0) > 0:
        auroc = roc_auc_score(all_labels, all_scores)
    else:
        auroc = 0.5
    
    return auroc

def main():
    args = parse_args()
    setup_seed(args.seed)
    device = torch.device(f'cuda:{args.device_id}')
    os.makedirs(args.save_path, exist_ok=True)
    
    # 加载预计算tex_map
    print("加载预计算tex_map...")
    tex_maps = np.load(args.tex_map_path)
    print(f"  tex_maps shape: {tex_maps.shape}")
    
    # 加载CMGL模型
    print("加载CMGL模型...")
    with open(args.config_path, 'r') as f:
        model_configs = json.load(f)
    
    model, _, preprocess_test = Load_CLIP(
        args.image_size, args.pretrained_path, device=device,
        deep_prompt_len=args.deep_prompt_len,
        total_d_layer_len=args.total_d_layer_len)
    model.to(device)
    
    linearlayer = LinearLayer(model_configs['vision_cfg']['width'], model_configs['embed_dim'],
                              len(args.features_list), args.model).to(device)
    New_Lan_Embed = Context_Prompting(model_configs, cla_len=args.prompt_len).to(device)
    prompt_ceshi = Prompt_Ensemble(args.prompt_len, tokenize)
    UFAMTemplate = UAFM(dim_v=model_configs["vision_cfg"]['width'],
                        dim_t=model_configs["text_cfg"]['width'],
                        dim_out=model_configs["vision_cfg"]['width']).to(device)
    model_tf = LCBlock(refine_type="transformer").to(device)
    
    checkpoint = torch.load(args.checkpoint_path, map_location=device)
    linearlayer.load_state_dict(checkpoint["trainable_linearlayer"], strict=False)
    New_Lan_Embed.load_state_dict(checkpoint["New_Lan_Embed"])
    UFAMTemplate.load_state_dict(checkpoint["UFAMTemplate"], strict=False)
    model_tf.load_state_dict(checkpoint["ParallelThenRefine"], strict=False)
    _load_stages(model, checkpoint, "prompt")
    
    for p in model.parameters(): p.requires_grad = False
    for p in linearlayer.parameters(): p.requires_grad = False
    for p in New_Lan_Embed.parameters(): p.requires_grad = False
    for p in UFAMTemplate.parameters(): p.requires_grad = False
    for p in model_tf.parameters(): p.requires_grad = False
    model.eval(); linearlayer.eval(); New_Lan_Embed.eval()
    UFAMTemplate.eval(); model_tf.eval()
    
    # 初始化可训练模块
    print("初始化CBE + PixelFeatureBuilder + CategoryAwareMLP...")
    cbe = CBE(tex_dim=4096, sem_dim=1024, hidden_dim=256, out_dim=512).to(device)
    pfb = PixelFeatureBuilder(cross_dim=512, cross_reduce_dim=8, map_size=37).to(device)
    camlp = CategoryAwareMLP(pixel_dim=16, class_dim=768).to(device)
    
    optimizer = torch.optim.Adam(
        list(cbe.parameters()) + list(pfb.parameters()) + list(camlp.parameters()),
        lr=args.lr, weight_decay=1e-5)
    
    # 加权BCE Loss
    criterion = nn.BCELoss(weight=None)  # 手动加权
    
    # 数据集
    target_transform = transforms.Compose([
        transforms.Resize((args.image_size, args.image_size)),
        transforms.CenterCrop(args.image_size),
        transforms.ToTensor()
    ])
    dataset = VisaDataset(root=args.data_path, transform=preprocess_test,
                         target_transform=target_transform, mode='test',
                         train_mode="zero", dataset="visa")
    
    # 按类别划分训练/验证集（7:3）
    print(f"划分训练/验证集（{1-args.val_ratio:.1f}:{args.val_ratio:.1f}）...")
    cls_to_indices = {}
    for i, data in enumerate(dataset.data_all):
        cls = data['cls_name']
        if cls not in cls_to_indices:
            cls_to_indices[cls] = []
        cls_to_indices[cls].append(i)
    
    train_indices = []
    val_indices = []
    for cls, indices in cls_to_indices.items():
        np.random.shuffle(indices)
        n_val = int(len(indices) * args.val_ratio)
        val_indices.extend(indices[:n_val])
        train_indices.extend(indices[n_val:])
    
    train_dataset = Subset(dataset, train_indices)
    val_dataset = Subset(dataset, val_indices)
    print(f"  训练集: {len(train_dataset)}, 验证集: {len(val_dataset)}")
    
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False, num_workers=4)
    prompt_ceshi.build_state_pool(model, device)
    
    # 创建img_path到tex_map的映射
    print("构建img_path到tex_map映射...")
    img_path_to_tex = {}
    for i in range(len(dataset)):
        img_path = dataset.data_all[i]['img_path']
        img_path_to_tex[img_path] = tex_maps[i]
    
    # 训练
    print(f"\n开始训练（{args.epochs}轮，加权BCE pos_weight={args.pos_weight}）...")
    best_auroc = 0
    
    for epoch in range(args.epochs):
        cbe.train(); pfb.train(); camlp.train()
        epoch_loss = 0
        n_batches = 0
        
        for items in tqdm(train_loader, desc=f"Epoch {epoch+1}/{args.epochs}"):
            img = items['img'].to(device)
            gt_mask = items['img_mask'].to(device)
            cls_names = items['cls_name']
            img_paths = items['img_path']
            
            tex_map_batch = []
            for p in img_paths:
                rel_path = p.replace(args.data_path + '/', '')
                tex_map_batch.append(img_path_to_tex[rel_path])
            tex_map_batch = np.array(tex_map_batch)
            tex_map_2d = torch.from_numpy(tex_map_batch).float().to(device).view(-1, 37, 37)
            
            with torch.no_grad():
                tex_feats, sem_feats, sem_map, text_embeddings = extract_sem_features(
                    model, linearlayer, New_Lan_Embed, prompt_ceshi,
                    UFAMTemplate, model_tf, img, cls_names, device, args)
            
            cross_feat = cbe(tex_feats, sem_feats)
            pixel_feats = pfb(tex_map_2d, sem_map, cross_feat)
            class_embed = text_embeddings[:, 0, :]
            mlp_score = camlp(pixel_feats, class_embed)  # (B, N)
            
            # GT mask下采样
            gt_mask_37 = F.interpolate(gt_mask, size=37, mode='nearest').squeeze(1)
            gt_pixel = gt_mask_37.view(-1, 37*37)
            
            # 加权BCE：异常像素权重pos_weight
            weight = torch.ones_like(gt_pixel)
            weight[gt_pixel > 0.5] = args.pos_weight
            loss = F.binary_cross_entropy(mlp_score, gt_pixel, weight=weight)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss.item()
            n_batches += 1
        
        avg_loss = epoch_loss / max(n_batches, 1)
        
        # 验证集评估
        val_auroc = evaluate(model, linearlayer, New_Lan_Embed, prompt_ceshi, UFAMTemplate, model_tf,
                            cbe, pfb, camlp, val_loader, img_path_to_tex, device, args)
        
        print(f"Epoch {epoch+1}/{args.epochs}, Loss: {avg_loss:.6f}, Val AUROC: {val_auroc:.4f}")
        
        if val_auroc > best_auroc:
            best_auroc = val_auroc
            torch.save({
                'cbe': cbe.state_dict(),
                'pfb': pfb.state_dict(),
                'camlp': camlp.state_dict(),
            }, os.path.join(args.save_path, 'best_model.pth'))
            print(f"  保存最佳模型 (Val AUROC={best_auroc:.4f})")
    
    print(f"\n训练完成！最佳验证AUROC: {best_auroc:.4f}")

if __name__ == '__main__':
    main()
