"""预计算所有样本的tex_map（PatchCore KNN距离），分批采样避免内存溢出"""
import os, sys, json, argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from tqdm import tqdm

sys.path.insert(0, '/root/rxfang/CMGL-main')
sys.path.insert(0, '/root/rxfang/CMGL-main/cmgl_patchcorefuse')

from models.model_CLIP import Load_CLIP, tokenize
from models.prompt_ensemble import Prompt_Ensemble, LCBlock
from models.APV import Context_Prompting
from models.UAFM import UAFM
from cmgl_patchcorefuse.models.PatchCore import PatchCore
from utils.dataset import VisaDataset

class LinearLayer(nn.Module):
    def __init__(self, dim_in, dim_out, k, model):
        super().__init__()
        self.fc = nn.ModuleList([nn.Linear(dim_in, dim_out) for i in range(k)])
    def forward(self, tokens):
        return [self.fc[i](tokens[i][:, 1:, :]) for i in range(len(tokens))]

def _load_stages(model, params, exclude_key=None):
    for n, m in model.named_parameters():
        if exclude_key and exclude_key in n:
            m.data = params[n].data

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, default='/root/rxfang/CMGL-main/dataset/mvisa/data')
    parser.add_argument('--checkpoint_path', type=str, default='/root/rxfang/CMGL-main/my_exps/train_visa/epoch_1_group_id_2.pth')
    parser.add_argument('--pretrained_path', type=str, default='/root/rxfang/CMGL-main/pretrained_weight/ViT-L-14-336px.pt')
    parser.add_argument('--config_path', type=str, default='/root/rxfang/CMGL-main/models/model_configs/ViT-L-14.json')
    parser.add_argument('--save_path', type=str, default='/root/rxfang/CMGL-main/cmgl_patchcorefuse/features')
    parser.add_argument('--device_id', type=int, default=0)
    parser.add_argument('--features_list', type=int, nargs='+', default=[6, 12, 18, 24])
    parser.add_argument('--image_size', type=int, default=518)
    parser.add_argument('--batch_size', type=int, default=8)
    parser.add_argument('--coreset_ratio', type=float, default=0.01)
    parser.add_argument('--n_neighbors', type=int, default=3)
    parser.add_argument('--max_normal_feats', type=int, default=100000, help='最多保留的正常特征数')
    return parser.parse_args()

def main():
    args = parse_args()
    device = torch.device(f'cuda:{args.device_id}')
    os.makedirs(args.save_path, exist_ok=True)
    
    print("加载CMGL模型...")
    with open(args.config_path, 'r') as f:
        model_configs = json.load(f)
    
    model, _, preprocess_test = Load_CLIP(
        args.image_size, args.pretrained_path, device=device,
        deep_prompt_len=1, total_d_layer_len=11)
    model.to(device)
    model.eval()
    
    linearlayer = LinearLayer(model_configs['vision_cfg']['width'], model_configs['embed_dim'],
                              len(args.features_list), 'ViT-L-14-336').to(device)
    New_Lan_Embed = Context_Prompting(model_configs, cla_len=2).to(device)
    prompt_ceshi = Prompt_Ensemble(2, tokenize)
    UFAMTemplate = UAFM(dim_v=model_configs["vision_cfg"]['width'],
                        dim_t=model_configs["text_cfg"]['width'],
                        dim_out=model_configs["vision_cfg"]['width']).to(device)
    model_tf = LCBlock(refine_type="transformer").to(device)
    
    checkpoint = torch.load(args.checkpoint_path, map_location=device)
    linearlayer.load_state_dict(checkpoint["trainable_linearlayer"], strict=False)
    New_Lan_Embed.load_state_dict(checkpoint["New_Lan_Embed"])
    UFAMTemplate.load_state_dict(checkpoint["UFAMTemplate"], strict=False)
    model_tf.load_state_dict(checkpoint["ParallelThenRefine"], strict=False)
    _load_stages(model, checkpoint, "prompt")
    linearlayer.eval(); New_Lan_Embed.eval(); UFAMTemplate.eval(); model_tf.eval()
    
    target_transform = transforms.Compose([
        transforms.Resize((args.image_size, args.image_size)),
        transforms.CenterCrop(args.image_size),
        transforms.ToTensor()
    ])
    dataset = VisaDataset(root=args.data_path, transform=preprocess_test,
                         target_transform=target_transform, mode='test',
                         train_mode="zero", dataset="visa")
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=4)
    prompt_ceshi.build_state_pool(model, device)
    
    # 第一步：分批收集正常样本特征（在线采样，避免内存溢出）
    print(f"\n第一步：收集正常样本特征（最多{args.max_normal_feats}个）...")
    all_normal_feats = []
    total_collected = 0
    
    with torch.no_grad():
        for items in tqdm(dataloader, desc="收集正常特征"):
            if items['anomaly'][0] == 1:
                continue
            img = items['img'].to(device)
            _, patch_tokens = model.encode_image(img, args.features_list)
            tex_feats = torch.cat([pt[:, 1:, :] for pt in patch_tokens], dim=-1)
            feats_np = tex_feats.cpu().numpy().reshape(-1, 4096)
            
            # 随机采样10%
            n_sample = max(1, int(len(feats_np) * 0.1))
            indices = np.random.choice(len(feats_np), n_sample, replace=False)
            all_normal_feats.append(feats_np[indices])
            total_collected += n_sample
            
            if total_collected >= args.max_normal_feats:
                break
    
    all_normal_feats = np.concatenate(all_normal_feats, axis=0)
    print(f"  收集到 {all_normal_feats.shape[0]} 个正常特征")
    
    # 构建PatchCore Memory Bank
    print("构建PatchCore Memory Bank...")
    patchcore = PatchCore(coreset_ratio=args.coreset_ratio, n_neighbors=args.n_neighbors)
    patchcore.build_memory_bank(all_normal_feats)
    patchcore.save(os.path.join(args.save_path, 'patchcore_memory.npz'))
    
    # 释放内存
    del all_normal_feats
    import gc; gc.collect()
    
    # 第二步：预计算所有样本的tex_map
    print("\n第二步：预计算所有样本的tex_map...")
    all_tex_maps = []
    all_labels = []
    all_cls = []
    
    with torch.no_grad():
        for items in tqdm(dataloader, desc="计算tex_map"):
            img = items['img'].to(device)
            _, patch_tokens = model.encode_image(img, args.features_list)
            tex_feats = torch.cat([pt[:, 1:, :] for pt in patch_tokens], dim=-1)
            tex_map = patchcore.predict(tex_feats.cpu().numpy())
            all_tex_maps.append(tex_map)
            all_labels.extend(items['anomaly'].numpy())
            all_cls.extend(items['cls_name'])
    
    all_tex_maps = np.concatenate(all_tex_maps, axis=0)
    all_labels = np.array(all_labels)
    all_cls = np.array(all_cls)
    
    np.save(os.path.join(args.save_path, 'tex_maps.npy'), all_tex_maps)
    np.save(os.path.join(args.save_path, 'labels.npy'), all_labels)
    np.save(os.path.join(args.save_path, 'cls_names.npy'), all_cls)
    
    print(f"\n预计算完成！")
    print(f"  tex_maps shape: {all_tex_maps.shape}")
    print(f"  正常: {np.sum(all_labels==0)}, 异常: {np.sum(all_labels==1)}")
    print(f"  保存到: {args.save_path}")

if __name__ == '__main__':
    main()
