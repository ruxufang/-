"""内存/显存保护工具 - 监控使用率，超阈值时优雅退出"""
import os
import sys
import time
import signal
import threading
import logging

logger = logging.getLogger(__name__)

class MemoryGuard:
    """内存/显存监控保护器
    
    监控CPU内存和GPU显存使用率，超过阈值时触发回调或直接退出。
    """
    def __init__(self, 
                 cpu_mem_threshold=0.85, 
                 gpu_mem_threshold=0.90,
                 check_interval=5.0,
                 gpu_device_id=0,
                 on_alert=None,
                 auto_kill=True,
                 save_callback=None):
        """
        Args:
            cpu_mem_threshold: CPU内存使用率阈值（0-1），默认85%
            gpu_mem_threshold: GPU显存使用率阈值（0-1），默认90%
            check_interval: 检查间隔（秒），默认5秒
            gpu_device_id: 监控的GPU设备ID
            on_alert: 告警回调函数 callback(alert_type, usage)
            auto_kill: 是否自动杀死进程
            save_callback: 退出前保存模型的回调
        """
        self.cpu_mem_threshold = cpu_mem_threshold
        self.gpu_mem_threshold = gpu_mem_threshold
        self.check_interval = check_interval
        self.gpu_device_id = gpu_device_id
        self.on_alert = on_alert
        self.auto_kill = auto_kill
        self.save_callback = save_callback
        self._running = False
        self._thread = None
        self._alert_count = 0
        self._max_alert_count = 3  # 连续告警3次才退出
        
    def _get_cpu_memory_usage(self):
        """获取CPU内存使用率"""
        try:
            import psutil
            mem = psutil.virtual_memory()
            return mem.percent / 100.0, mem.used / (1024**3), mem.total / (1024**3)
        except ImportError:
            # 没有psutil时用/proc/meminfo
            try:
                with open('/proc/meminfo', 'r') as f:
                    lines = f.readlines()
                mem_total = int(lines[0].split()[1]) * 1024
                mem_available = int(lines[2].split()[1]) * 1024
                mem_used = mem_total - mem_available
                return mem_used / mem_total, mem_used / (1024**3), mem_total / (1024**3)
            except:
                return 0, 0, 0
    
    def _get_gpu_memory_usage(self):
        """获取GPU显存使用率"""
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(self.gpu_device_id)
            info = pynvml.nvmlDeviceGetMemoryInfo(handle)
            pynvml.nvmlShutdown()
            return info.used / info.total, info.used / (1024**3), info.total / (1024**3)
        except:
            # 没有pynvml时用nvidia-smi
            try:
                import subprocess
                result = subprocess.run(
                    ['nvidia-smi', f'--id={self.gpu_device_id}', 
                     '--query-gpu=memory.used,memory.total', 
                     '--format=csv,noheader,nounits'],
                    capture_output=True, text=True, timeout=5)
                used, total = map(float, result.stdout.strip().split(','))
                return used / total, used / 1024, total / 1024
            except:
                return 0, 0, 0
    
    def _check_loop(self):
        """监控循环"""
        while self._running:
            try:
                cpu_usage, cpu_used, cpu_total = self._get_cpu_memory_usage()
                gpu_usage, gpu_used, gpu_total = self._get_gpu_memory_usage()
                
                alert_triggered = False
                alert_type = None
                
                if cpu_usage > self.cpu_mem_threshold and cpu_usage > 0:
                    alert_type = 'CPU_MEMORY'
                    alert_triggered = True
                    logger.warning(f"[MemoryGuard] CPU内存告警: {cpu_used:.1f}GB/{cpu_total:.1f}GB ({cpu_usage*100:.1f}%) > {self.cpu_mem_threshold*100:.0f}%")
                
                if gpu_usage > self.gpu_mem_threshold and gpu_usage > 0:
                    alert_type = 'GPU_MEMORY'
                    alert_triggered = True
                    logger.warning(f"[MemoryGuard] GPU显存告警: {gpu_used:.1f}GB/{gpu_total:.1f}GB ({gpu_usage*100:.1f}%) > {self.gpu_mem_threshold*100:.0f}%")
                
                if alert_triggered:
                    self._alert_count += 1
                    if self.on_alert:
                        self.on_alert(alert_type, cpu_usage if alert_type=='CPU_MEMORY' else gpu_usage)
                    
                    if self._alert_count >= self._max_alert_count:
                        logger.error(f"[MemoryGuard] 连续{self._max_alert_count}次告警，触发保护退出！")
                        self._safe_exit(alert_type)
                else:
                    self._alert_count = 0  # 重置告警计数
                    
            except Exception as e:
                logger.error(f"[MemoryGuard] 监控异常: {e}")
            
            time.sleep(self.check_interval)
    
    def _safe_exit(self, reason):
        """安全退出：先保存模型，再退出"""
        logger.error(f"[MemoryGuard] 安全退出，原因: {reason}")
        
        if self.save_callback:
            try:
                logger.info("[MemoryGuard] 执行保存回调...")
                self.save_callback()
            except Exception as e:
                logger.error(f"[MemoryGuard] 保存回调失败: {e}")
        
        if self.auto_kill:
            logger.error("[MemoryGuard] 杀死进程，防止系统OOM...")
            os.kill(os.getpid(), signal.SIGTERM)
    
    def start(self):
        """启动监控"""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._check_loop, daemon=True)
        self._thread.start()
        logger.info(f"[MemoryGuard] 监控已启动 (CPU阈值:{self.cpu_mem_threshold*100:.0f}%, GPU阈值:{self.gpu_mem_threshold*100:.0f}%, 间隔:{self.check_interval}s)")
    
    def stop(self):
        """停止监控"""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("[MemoryGuard] 监控已停止")
    
    def get_current_usage(self):
        """获取当前使用率"""
        cpu_usage, cpu_used, cpu_total = self._get_cpu_memory_usage()
        gpu_usage, gpu_used, gpu_total = self._get_gpu_memory_usage()
        return {
            'cpu_usage': cpu_usage,
            'cpu_used_gb': cpu_used,
            'cpu_total_gb': cpu_total,
            'gpu_usage': gpu_usage,
            'gpu_used_gb': gpu_used,
            'gpu_total_gb': gpu_total,
        }


def create_memory_guard(save_callback=None, 
                        cpu_threshold=0.85, 
                        gpu_threshold=0.90,
                        device_id=0):
    """创建并启动内存保护器的便捷函数
    
    Args:
        save_callback: 退出前保存模型的回调函数
        cpu_threshold: CPU内存告警阈值
        gpu_threshold: GPU显存告警阈值
        device_id: GPU设备ID
    
    Returns:
        MemoryGuard实例
    """
    # 配置日志
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[logging.StreamHandler()]
    )
    
    guard = MemoryGuard(
        cpu_mem_threshold=cpu_threshold,
        gpu_mem_threshold=gpu_threshold,
        check_interval=5.0,
        gpu_device_id=device_id,
        auto_kill=True,
        save_callback=save_callback
    )
    guard.start()
    return guard


if __name__ == '__main__':
    # 测试
    import time
    guard = create_memory_guard()
    try:
        while True:
            usage = guard.get_current_usage()
            print(f"CPU: {usage['cpu_used_gb']:.1f}GB/{usage['cpu_total_gb']:.1f}GB ({usage['cpu_usage']*100:.1f}%)"
                  f"  GPU: {usage['gpu_used_gb']:.1f}GB/{usage['gpu_total_gb']:.1f}GB ({usage['gpu_usage']*100:.1f}%)")
            time.sleep(2)
    except KeyboardInterrupt:
        guard.stop()
